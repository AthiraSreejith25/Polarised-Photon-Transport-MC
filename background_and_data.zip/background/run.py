from os import system

for i in range(1,4):

	system('python3 polarised_1.5.{}.py'.format(i))
